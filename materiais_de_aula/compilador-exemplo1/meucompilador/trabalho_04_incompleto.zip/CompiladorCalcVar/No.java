package CompiladorCalcVar;

public abstract class No {}
