package CompiladorCalcVar;

public enum TipoToken {
    INTEIRO,
    MAIS,
    MENOS,
    MULTIPLICA,
    DIVIDE,
    ABRE_PARENTESES,
    FECHA_PARENTESES,
    DECLARACAO,
    PONTO_VIRGULA,
    IDENTIFICADOR,
    EOF
}
