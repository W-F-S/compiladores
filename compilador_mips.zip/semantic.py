class SemanticAnalyzer:
    def __init__(self, ast):
        self.ast = ast
        self.symbol_table = set()

    def analyze(self):
        for node in self.ast:
            if node[0] == 'declare':
                if node[1] in self.symbol_table:
                    raise Exception(f"Erro semântico: variável '{node[1]}' já declarada")
                self.symbol_table.add(node[1])
            elif node[0] == 'assign':
                if node[1] not in self.symbol_table:
                    raise Exception(f"Erro semântico: variável '{node[1]}' não declarada")
                self.check_expr(node[2])
            elif node[0] == 'print':
                if node[1] not in self.symbol_table:
                    raise Exception(f"Erro semântico: variável '{node[1]}' não declarada")

    def check_expr(self, expr):
        if expr[0] in ('PLUS', 'MINUS'):
            self.check_expr(expr[1])
            self.check_expr(expr[2])
        elif expr[0] == 'var' and expr[1] not in self.symbol_table:
            raise Exception(f"Erro semântico: variável '{expr[1]}' não declarada")