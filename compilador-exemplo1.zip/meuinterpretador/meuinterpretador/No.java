package meuinterpretador;

public abstract class No {}
