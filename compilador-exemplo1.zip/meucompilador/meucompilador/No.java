package meucompilador;

public abstract class No {}
