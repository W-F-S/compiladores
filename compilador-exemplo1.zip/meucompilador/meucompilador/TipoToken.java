package meucompilador;

public enum TipoToken {
    INTEIRO,
    MAIS,
    MENOS,
    MULTIPLICA,
    DIVIDE,
    ABRE_PARENTESES,
    FECHA_PARENTESES,
    EOF
}
